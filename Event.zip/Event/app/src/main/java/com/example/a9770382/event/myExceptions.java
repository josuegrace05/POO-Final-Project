package com.example.a9770382.event;

/**
 * Created by 9770382 on 14/06/2017.
 */

public class myExceptions {

    public boolean status;
    public String message;

    public myExceptions(boolean status,String message){
        this.status = status;
        this.message = message;

    }
}
