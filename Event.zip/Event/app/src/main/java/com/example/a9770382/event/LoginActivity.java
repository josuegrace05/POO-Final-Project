package com.example.a9770382.event;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final EditText emailText = (EditText) findViewById(R.id.emailText);
        final EditText passwordText = (EditText) findViewById(R.id.passwordText);
        final Button signInButton = (Button) findViewById(R.id.signInButton);
        final Button signUpButton = (Button) findViewById(R.id.signUpButton);
        signInButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                String email = emailText.getText().toString();
                String password = passwordText.getText().toString();

                // Verifica o login.
                Database db = new Database();
                String name = User.selectUserName(email, password);
                AlertDialog.Builder alt = new AlertDialog.Builder(LoginActivity.this);

                Log.e("Verifica", "antes test");
                if(db.test == 1)
                    alt.setMessage("Foiii!.")
                            .setNegativeButton("Try Again", null).create().show();

                if(name != null){
                    // TODO Email e senha batem => chama a nova Activity
                    Toast.makeText(getApplicationContext(), "Login OK!", Toast.LENGTH_LONG).show();
                    User user = new User(name, email, password);
                }
                else {
                    AlertDialog.Builder alertLogin = new AlertDialog.Builder(LoginActivity.this);
                    alertLogin.setMessage("The e-mail and/or passwords are invalids.")
                            .setNegativeButton("Try Again", null).create().show();
                }
            }
        });
    }

    public void SignUpButton(View view) {
        Intent intent = new Intent(this,SignUpActivity.class);
        startActivity(intent);
    }
}
