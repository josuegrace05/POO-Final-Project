package com.example.a9770382.event;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;

/**
 * Created by 9770382 on 14/06/2017.
 */

public class RegisterRequest extends StringRequest {
    private static final String RegisterRequestURL = "https://joekbg5.000webhostapp.com/signIn/register.php";
    private HashMap<String, String> parameters;

    public RegisterRequest(String username, String email, String password, Response.Listener<String> listener){
        super(Method.POST, RegisterRequestURL, listener, null);
        parameters = new HashMap<>();
        parameters.put("username", username);
        parameters.put("email", email);
        parameters.put("password", password);
    }

    public HashMap<String, String> getParameters() {
        return parameters;
    }
}
